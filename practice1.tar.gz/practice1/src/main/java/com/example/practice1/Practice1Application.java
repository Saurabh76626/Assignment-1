package com.example.practice1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import javax.sql.DataSource;

@SpringBootApplication
public class Practice1Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Practice1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

	}


	// Practice1Service practice1Service = ApplicationContext.getBean("practice1Service",Practice1Service.class);
}
