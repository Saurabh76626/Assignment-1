package com.example.practice1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping
public class Practice1Controller {
    @Autowired
     Practice1Service practice1Service;
    @PostMapping(value="/submit")
    public void Postpractice(@RequestBody List<Practice1model> practice1model)
    {
        practice1Service.addpractice(practice1model);
    }
    @GetMapping(value = "/status/{id}")
    public Optional<Practice1model> GetPractice(@PathVariable ("id") Integer id)
    {
        return practice1Service.getPractice(id);
    }
    @RequestMapping(value = "/output/{id}")
    public List<Integer> Names(@PathVariable ("id") Integer id)
    {

        return practice1Service.AllRecord(id);
    }


}
