package com.example.practice1;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.CrudRepositoryExtensionsKt;
import org.springframework.stereotype.Repository;
import java.util.*;
import java.util.List;

@Repository

public interface Practice1Dob extends CrudRepository<Practice1model,String> {
    @Query(value = "select p from Practice1model p where p.id = ?1")
    Practice1model findByid(String ID);


}
