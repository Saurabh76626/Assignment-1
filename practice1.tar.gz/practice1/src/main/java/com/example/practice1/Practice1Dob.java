package com.example.practice1;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository

public interface Practice1Dob extends CrudRepository<Practice1model,Integer> {
  @Query(value = "select p from Practice1model p where p.id = ?1")
  Practice1model findByid(Integer id);
Optional<Practice1model> findById(Integer id);

}
