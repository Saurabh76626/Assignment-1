package com.example.practice1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class Practice1Service {
    @Autowired
    Practice1Dob practice1Dob;
    Practice1Service practice1Service;
    public void addpractice(List<Practice1model> practice1model)
    {
        practice1Dob.saveAll(practice1model);


    }
    public Practice1model getPractice(String id)
    {
        return practice1Dob.findByid(id);
    }

   public List<Integer> AllRecord(String id)
   {
       Practice1model practice1model = practice1Dob.findByid(id);
       List<Integer>file = Arrays.asList();
       file.add(practice1model.getFirst()+practice1model.getSecond());
       return file;
   }


}
