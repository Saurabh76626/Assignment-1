package com.example.practice1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class Practice1Service {
    @Autowired
    Practice1Dob practice1Dob;
    Practice1Service practice1Service;
    public void addpractice(List<Practice1model> practice1model)
    {
        practice1Dob.saveAll(practice1model);


    }
    public Optional<Practice1model> getPractice(Integer id)
    {
        return practice1Dob.findById(id);
    }

   public List<Integer> AllRecord(Integer id)
   {
       Practice1model practice1model = practice1Dob.findByid(id);
       int sum = practice1model.getFirst() + practice1model.getSecond();
      List<Integer>file = Arrays.asList(sum);
//       file.add(2);
       return file;
   }


}
