package com.example.practice1;

import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.Optional;

@Entity
@DynamicUpdate
/*@NamedNativeQueries(value = {
        @NamedNativeQuery(name = "Pratice1model.findByname" , query = "select*  from practice1model  where  name =?1",resultClass = Practice1model.class),
        @NamedNativeQuery(name = "Practice1model.findByNameAndAge" , query = "select * from practice1model  where name=?1 and age=?2",resultClass = Practice1model.class)
})*/
@Table
public class Practice1model {
    @Id
    //@GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id",nullable = false,unique = true)
    private String id;
    @Column(name = "first",nullable = false)
    private Integer first;
    @Column(name ="second",nullable = false)
    private Integer second;

    public Integer getFirst() {
        return first;
    }

    public void setFirst(Integer first) {
        this.first = first;
    }

    public Integer getSecond() {
        return second;
    }

    public void setSecond(Integer second) {
        this.second = second;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
