package com.example.demo;

import com.sun.jndi.toolkit.url.Uri;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.awt.*;

public class DemoService {


    public void start(String browser, String url) {
        if(browser.equals("chrome")) {
            ChromeDriver driver = new ChromeDriver();
            System.setProperty("webdriver.chrome.driver", "./lib/google-chrome");
            driver.get(url);
        }
        else if(browser.equals("mozilla"))
        {
          FirefoxDriver driver = new FirefoxDriver();
            System.setProperty("webdriver.firefox.driver", "./lib/mozila-firefox");
            driver.get(url);
        }
    }

    public void stop1(String browser) {

        if(browser.equals("chrome")) {
            ChromeDriver driver = new ChromeDriver();
            System.setProperty("webdriver.chrome.driver", "./lib/chrome");
            driver.quit();
        }
        else if(browser.equals("mozilla"))
        {
            FirefoxDriver driver = new FirefoxDriver();
            System.setProperty("webdriver.firefox.driver", "./lib/mozila-firefox");
            driver.quit();
        }

    }

    public String gettab(String browser) {
        if(browser.equals("chrome")) {
            ChromeDriver driver = new ChromeDriver();
            return driver.getCurrentUrl();
        }
        else if(browser.equals("mozilla"))
        {
            FirefoxDriver driver = new FirefoxDriver();
            return driver.getCurrentUrl();
        }
        else
            return null;
    }

    public void cleanhistory(String browser) {
        if(browser.equals("chrome")) {
            ChromeDriver driver = new ChromeDriver();
            driver.manage().deleteAllCookies();
        }
        else if(browser.equals("mozilla"))
        {
            FirefoxDriver driver = new FirefoxDriver();
            driver.manage().deleteAllCookies();
        }
    }
}
