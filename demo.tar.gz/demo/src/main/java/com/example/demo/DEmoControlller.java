package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DEmoControlller {
       DemoService demoService;
      @GetMapping(value = "/start/{browser}/{url}")
      public void Start(@PathVariable("browser")String browser,@PathVariable("url")String url)
      {
               demoService.start(browser,url);
      }
      @GetMapping(value = "/stop/{browser}")
     public void stop (@PathVariable("browser")String browser)
      {
              demoService.stop1(browser);
      }
      @GetMapping(value = "/cleanup/{browser}")
    public void Clean(@PathVariable("browser")String browser)
      {
          demoService.cleanhistory(browser);
      }
      @GetMapping(value = "/geturl/{browser}")
     public String get(@PathVariable("browser")String browser)
      {
           return demoService.gettab(browser);
      }
}
